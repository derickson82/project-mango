package org.newdawn.warpstone;

public interface DungeonElement {

	public void addedToMap(LevelMap map);
	
	public void removedFromMap(LevelMap map);
	
}
